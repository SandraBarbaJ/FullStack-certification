export default{
    USER ='standard_user',
    PASSWORD = 'secret_sauce',
    WRONGPASS = 'hola',
    FIRSTNAME = 'Sandra',
    LASTNAME = 'Barba',
    ZIPCODE = '44444',
 };